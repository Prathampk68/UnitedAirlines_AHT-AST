#!/usr/bin/env python
# coding: utf-8

# # Importing files and Libraries

# In[139]:


import pandas as pd
import matplotlib.pyplot as plt


# In[146]:


calls_df = pd.read_csv('calls.csv')
customers_df = pd.read_csv('customers.csv')
reasons_df = pd.read_csv('reasons.csv')
sentiment_df = pd.read_csv('sentiment_statistics.csv')


# # Data Cleaning

# In[148]:


## Removing missing,dublicates (if any), outliers etc


# In[149]:


print(calls_df.isnull().sum())


# In[153]:


# Assuming 0 means no loyalty status
customers_df['elite_level_code'] = customers_df['elite_level_code'].fillna(0)


# In[155]:


# Replace NaN with mean sentiment
sentiment_df['average_sentiment'] = sentiment_df['average_sentiment'].fillna(sentiment_df['average_sentiment'].mean())


# In[157]:


# Fill missing agent_tone with the most frequent value (mode)
mode_value = sentiment_df['agent_tone'].mode()[0]
sentiment_df['agent_tone'] = sentiment_df['agent_tone'].fillna(mode_value)


# In[159]:


calls_df.drop(columns=['Unnamed: 7','AHT','AST'],inplace=True)


# In[161]:


# Check for missing values-> ALl DATA GET CLEANED
print(calls_df.isnull().sum())
print(customers_df.isnull().sum())
print(reasons_df.isnull().sum())
print(sentiment_df.isnull().sum())


# In[163]:


## Converting data_types
# Convert date columns to datetime type
calls_df['call_start_datetime'] = pd.to_datetime(calls_df['call_start_datetime'])
calls_df['agent_assigned_datetime'] = pd.to_datetime(calls_df['agent_assigned_datetime'])
calls_df['call_end_datetime'] = pd.to_datetime(calls_df['call_end_datetime'])


# In[165]:


# Convert elite_level_code to categorical type
customers_df['elite_level_code'] = customers_df['elite_level_code'].astype('category')


# In[167]:


# Handling Outliers
# Calculate AHT and AST
calls_df['AHT'] = (calls_df['call_end_datetime'] - calls_df['agent_assigned_datetime']).dt.total_seconds()/60
calls_df['AST'] = (calls_df['agent_assigned_datetime'] - calls_df['call_start_datetime']).dt.total_seconds()/60

#AHT average handle time 


# In[169]:


import seaborn as sns


# In[171]:


# Boxplot to detect outliers
plt.figure(figsize=(12, 6))
sns.boxplot(x=calls_df['AHT'])
plt.title('Boxplot for AHT to Identify Outliers')
plt.show()


# In[173]:


# Removing outliers (for instance, using IQR method)
Q1 = calls_df['AHT'].quantile(0.25)
Q3 = calls_df['AHT'].quantile(0.75)
IQR = Q3 - Q1


# In[175]:


# Filter out outliers
calls_df = calls_df[~((calls_df['AHT'] < (Q1 - 1.5 * IQR)) | (calls_df['AHT'] > (Q3 + 1.5 * IQR)))]


# In[177]:


# Boxplot after removing outliers
plt.figure(figsize=(12, 6))
sns.boxplot(x=calls_df['AHT'])
plt.title('Boxplot for AHT to Identify Outliers')
plt.show() 


# In[179]:


# Boxplot after removing outliers
plt.figure(figsize=(12, 6))
sns.boxplot(x=calls_df['AST'])
plt.title('Boxplot for AST to Identify Outliers')
plt.show()


# In[181]:


# Standardizing call transcripts (convert to lowercase)
calls_df['call_transcript'] = calls_df['call_transcript'].str.lower()

# Clean customer names by stripping whitespace
customers_df['customer_name'] = customers_df['customer_name'].str.strip()


# In[236]:


#Merging all the files available into one df


# In[183]:


merged_df= calls_df.merge(reasons_df, on='call_id', how='left')


# In[185]:


merged_df=merged_df.merge(customers_df,on='customer_id',how='left')


# In[187]:


merged_df=merged_df.merge(sentiment_df,on='call_id',how='left')


# In[189]:


merged_df = merged_df.rename(columns={'agent_id_x': 'agent_id'})


# In[191]:


merged_df.drop(columns=['agent_id_y'],inplace=True)


# In[193]:


print(merged_df.duplicated().sum())


# In[195]:


merged_df


# # Exploratory Data Analysis(EDA)

# In[241]:


# Step 1:Cleaning Call Transcripts by Removing Stopwords and Punctuation


# In[197]:


import nltk
from nltk.corpus import stopwords
import string

# Load stopwords and define punctuation set
nltk.download('stopwords')
stop_words = set(stopwords.words('english'))
punctuation = set(string.punctuation)

# Define a function to clean the transcripts
def clean_transcript(text):
    # Tokenize the text
    words = nltk.word_tokenize(text.lower())
    # Remove stopwords and punctuation
    cleaned_words = [word for word in words if word not in stop_words and word not in punctuation]
    return ' '.join(cleaned_words)


# In[203]:


# Apply cleaning function to the call_transcript column
merged_df['cleaned_transcript'] = merged_df['call_transcript'].apply(clean_transcript)

# Display the cleaned transcripts
print(merged_df[['cleaned_transcript', 'primary_call_reason']].head())


# In[207]:


# Step 2: Text Mining Using TF-IDF


# In[209]:


from sklearn.feature_extraction.text import TfidfVectorizer

# Vectorize the cleaned transcripts using TF-IDF
tfidf_vectorizer = TfidfVectorizer(max_features=100)
tfidf_matrix = tfidf_vectorizer.fit_transform(merged_df['cleaned_transcript'])

# Convert the matrix into a DataFrame for easy analysis
tfidf_df = pd.DataFrame(tfidf_matrix.toarray(), columns=tfidf_vectorizer.get_feature_names_out())

# Add the primary_call_reason to the DataFrame for reference
tfidf_df['primary_call_reason'] = merged_df['primary_call_reason'].values

# Display the TF-IDF matrix
print(tfidf_df.head())


# In[211]:


# Step 3: Grouping Call Reasons Based on Transcripts


# In[213]:


# Group by 'primary_call_reason' and calculate the mean TF-IDF scores for each keyword
reason_grouped_tfidf = tfidf_df.groupby('primary_call_reason').mean()

# Display the top words associated with each call reason
print(reason_grouped_tfidf.head())


# In[215]:


# Step 4: Analyzing Keyword Frequency


# In[217]:


# Function to get top N keywords for each call reason
def get_top_keywords(call_reason, n=10):
    keywords = reason_grouped_tfidf.loc[call_reason].sort_values(ascending=False)
    return keywords.head(n)

# Example: Get top 10 keywords for the 'Baggage' call reason
top_keywords_baggage = get_top_keywords('Baggage', 10)
print("Top keywords for Baggage issues:")
print(top_keywords_baggage)


# In[219]:


# Step 5: Sentiment Analysis of Call Transcripts


# In[221]:


import nltk
nltk.download('brown')
nltk.download('punkt')


# In[231]:


get_ipython().system('pip install textblob')


# In[232]:


from textblob import TextBlob

# Define a function to calculate sentiment polarity
def get_sentiment(text):
    return TextBlob(text).sentiment.polarity

# Apply sentiment analysis to the cleaned transcripts
merged_df['sentiment'] = merged_df['cleaned_transcript'].apply(get_sentiment)

# Group by primary_call_reason and calculate average sentiment for each reason
reason_sentiment = merged_df.groupby('primary_call_reason')['sentiment'].mean()

# Display the average sentiment for each call reason
print(reason_sentiment)


# In[233]:


#Step 6: Visualize Results-> By plotting bar graph and wordcloud


# In[234]:


# Plot average sentiment for each call reason
plt.figure(figsize=(10,6))
reason_sentiment.sort_values().plot(kind='bar')
plt.title('Average Sentiment for Each Call Reason')
plt.ylabel('Average Sentiment Score')
plt.xlabel('Primary Call Reason')
plt.xticks(rotation=90)
plt.show()


# In[113]:


from wordcloud import WordCloud

# Generate a word cloud for the entire corpus
all_words = ' '.join(merged_df['cleaned_transcript'].tolist())
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(all_words)

# Plot the word cloud
plt.figure(figsize=(10, 6))
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.title('Word Cloud of Call Transcripts')
plt.show()


# In[ ]:




