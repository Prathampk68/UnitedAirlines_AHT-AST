#!/usr/bin/env python
# coding: utf-8

# In[4]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


# # 1.Importing Files
# 

# In[6]:


calls_df = pd.read_csv('calls.csv')
customers_df = pd.read_csv('customers.csv')
reasons_df = pd.read_csv('reasons.csv')
sentiment_df = pd.read_csv('sentiment_statistics.csv')


# In[8]:


calls_df


# # 2. DATA CLEANING

# In[12]:


print(calls_df.isnull().sum())


# In[14]:


calls_df.drop(columns=['Unnamed: 7','AHT','AST'],inplace=True)


# In[16]:


print(calls_df.isnull().sum())


# In[18]:


print(customers_df.isnull().sum())


# In[20]:


print(reasons_df.isnull().sum())


# In[22]:


print(sentiment_df.isnull().sum())


# In[24]:


# Assuming 0 means no loyalty status->filling missing data
customers_df['elite_level_code'] = customers_df['elite_level_code'].fillna(0)


# In[26]:


customers_df


# In[28]:


print(customers_df.isnull().sum())


# In[30]:


# Replace NaN with mean sentiment
sentiment_df['average_sentiment'] = sentiment_df['average_sentiment'].fillna(sentiment_df['average_sentiment'].mean())


# In[32]:


print(sentiment_df.isnull().sum())


# In[34]:


sentiment_df


# In[36]:


# Fill missing agent_tone with the most frequent value (mode)
mode_value = sentiment_df['agent_tone'].mode()[0]
sentiment_df['agent_tone'] = sentiment_df['agent_tone'].fillna(mode_value)


# In[38]:


# Check for missing values-> ALl DATA GET CLEANED
print(calls_df.isnull().sum())
print(customers_df.isnull().sum())
print(reasons_df.isnull().sum())
print(sentiment_df.isnull().sum())


# In[40]:


# Check for duplicates
print(calls_df.duplicated().sum())
print(customers_df.duplicated().sum())
print(reasons_df.duplicated().sum())
print(sentiment_df.duplicated().sum())


# In[42]:


## Converting data_types
# Convert date columns to datetime type
calls_df['call_start_datetime'] = pd.to_datetime(calls_df['call_start_datetime'])
calls_df['agent_assigned_datetime'] = pd.to_datetime(calls_df['agent_assigned_datetime'])
calls_df['call_end_datetime'] = pd.to_datetime(calls_df['call_end_datetime'])


# In[44]:


# Convert elite_level_code to categorical type
customers_df['elite_level_code'] = customers_df['elite_level_code'].astype('category')


# In[46]:


# Check for any improper data types
print(calls_df.dtypes)
print(customers_df.dtypes)


# In[48]:


# Handling Outliers
# Calculate AHT and AST
calls_df['AHT'] = (calls_df['call_end_datetime'] - calls_df['agent_assigned_datetime']).dt.total_seconds()/60
calls_df['AST'] = (calls_df['agent_assigned_datetime'] - calls_df['call_start_datetime']).dt.total_seconds()/60

#AHT average handle time 


# In[50]:


print(calls_df[['call_id', 'AHT', 'AST']].head(10))


# In[52]:


# Boxplot to detect outliers
plt.figure(figsize=(12, 6))
sns.boxplot(x=calls_df['AHT'])
plt.title('Boxplot for AHT to Identify Outliers')
plt.show()


# In[54]:


# Removing outliers (for instance, using IQR method)
Q1 = calls_df['AHT'].quantile(0.25)
Q3 = calls_df['AHT'].quantile(0.75)
IQR = Q3 - Q1


# In[56]:


# Filter out outliers
calls_df = calls_df[~((calls_df['AHT'] < (Q1 - 1.5 * IQR)) | (calls_df['AHT'] > (Q3 + 1.5 * IQR)))]


# In[58]:


# Boxplot after removing outliers
plt.figure(figsize=(12, 6))
sns.boxplot(x=calls_df['AHT'])
plt.title('Boxplot for AHT to Identify Outliers')
plt.show() 


# In[60]:


# Boxplot after removing outliers
plt.figure(figsize=(12, 6))
sns.boxplot(x=calls_df['AST'])
plt.title('Boxplot for AST to Identify Outliers')
plt.show()


# In[66]:


reasons_df.columns


# In[68]:


# Standardizing call transcripts (convert to lowercase)
calls_df['call_transcript'] = calls_df['call_transcript'].str.lower()

# Clean customer names by stripping whitespace
customers_df['customer_name'] = customers_df['customer_name'].str.strip()


# In[70]:


# Final inspection of cleaned data
print(calls_df.info())
print(customers_df.info())
print(reasons_df.info())
print(sentiment_df.info())


# In[72]:


# Merging of different CSV files into one single df


# In[92]:


merged_df= calls_df.merge(reasons_df, on='call_id', how='left')



# In[94]:


merged_df=merged_df.merge(customers_df,on='customer_id',how='left')


# In[96]:


merged_df=merged_df.merge(sentiment_df,on='call_id',how='left')


# In[98]:


merged_df


# In[100]:


merged_df = merged_df.rename(columns={'agent_id_x': 'agent_id'})


# In[102]:


merged_df.info()


# # 3.Exploratory Data Analysis (EDA)

# # 3a Univarite Analysis
# 

# In[106]:


#Distribution of AHT
plt.figure(figsize=(10,6))
sns.histplot(merged_df['AHT'], kde=True, bins=30)
plt.title('Distribution of AHT (Average Handle Time)')
plt.xlabel('AHT (minutes)')
plt.ylabel('Frequency')
plt.show()


# In[108]:


# Distribution of AST
plt.figure(figsize=(10,6))
sns.histplot(merged_df['AST'], kde=True, bins=30)
plt.title('Distribution of AST (Average Speed to Answer)')
plt.xlabel('AST (minutes)')
plt.ylabel('Frequency')
plt.show()


# # 3b Bivariate/Multivariate Analysis

# In[111]:


# Analyzing Call Reasons and Their Frequencies
# Plot the frequency of different call reasons
plt.figure(figsize=(12,6))
call_reason_counts = merged_df['primary_call_reason'].value_counts()
sns.barplot(x=call_reason_counts.index, y=call_reason_counts.values)
plt.title('Call Reasons Frequency')
plt.xlabel('Primary Call Reason')
plt.ylabel('Count')
plt.xticks(rotation=45, ha='right')
plt.show()


# In[113]:


# Sentiment and tone impact on AHT
tone_aht = merged_df.groupby(['customer_tone', 'agent_tone'])['AHT'].mean().reset_index()

# Plot AHT based on customer and agent tone
plt.figure(figsize=(10,6))
sns.barplot(x='customer_tone', y='AHT', hue='agent_tone', data=tone_aht)
plt.title('Average AHT by Customer Tone and Agent Tone')
plt.xlabel('Customer Tone')
plt.ylabel('Average AHT (minutes)')
plt.show()


# # 3c High-Volume Call Periods
# 

# In[116]:


#4.1  Analyzing Call Volume and AHT by Hour
# Add hour column
merged_df['call_start_hour'] = merged_df['call_start_datetime'].dt.hour

# Calculate average AHT and AST per hour
volume_aht = merged_df.groupby('call_start_hour')[['AHT', 'AST']].mean().reset_index()

# Plot AHT and AST by hour
plt.figure(figsize=(12,6))
sns.lineplot(x='call_start_hour', y='AHT', data=volume_aht, label='AHT')
sns.lineplot(x='call_start_hour', y='AST', data=volume_aht, label='AST')
plt.title('AHT and AST by Hour of the Day')
plt.xlabel('Hour of the Day')
plt.ylabel('Time (minutes)')
plt.legend()
plt.show()


# In[118]:


# Analyzing Silence Percentages
# Calculate the average AHT for different ranges of silence percentage
silence_aht = merged_df.groupby('silence_percent_average')['AHT'].mean().reset_index()

# Plot AHT based on silence percentage
plt.figure(figsize=(12,6))
sns.lineplot(x='silence_percent_average', y='AHT', data=silence_aht)
plt.title('AHT Based on Silence Percentages')
plt.xlabel('Silence Percentage')
plt.ylabel('Average AHT (minutes)')
plt.show()


# # 4.Quantifying the Percentage Difference in AHT for Most and Least Frequent Call Reasons:

# In[121]:


# 1. Agent Performance Analysis
agent_performance = merged_df.groupby('agent_id')['AHT'].mean().reset_index().sort_values('AHT', ascending=False)
print(agent_performance.head())


# In[123]:


# 2. Call Types and AHT
call_reason_aht = merged_df.groupby('primary_call_reason')['AHT'].mean().reset_index().sort_values('AHT', ascending=False)
print(call_reason_aht.head())


# In[125]:


# 3. Sentiment and Tone Analysis
tone_aht = merged_df.groupby(['customer_tone', 'agent_tone'])['AHT'].mean().reset_index().sort_values('AHT', ascending=False)
print(tone_aht.head(20))


# In[127]:


# 4. High Volume Call Periods
merged_df['call_start_hour'] = merged_df['call_start_datetime'].dt.hour
volume_aht = (
    merged_df.groupby('call_start_hour')[['AHT', 'AST']]
    .mean()
    .reset_index()
    .sort_values('AHT', ascending=False)
)

print(volume_aht.head())


# In[129]:


# 5. Silence Percent Impact on AHT
silence_aht = merged_df.groupby('silence_percent_average')['AHT'].mean().reset_index().sort_values('AHT', ascending=False)
print(silence_aht.head())


# In[131]:


# Find the most and least frequent call reasons
call_reason_counts = merged_df['primary_call_reason'].value_counts()
most_frequent_reason = call_reason_counts.index[0]
least_frequent_reason = call_reason_counts.index[-1]


# In[133]:


most_frequent_reason


# In[135]:


least_frequent_reason


# In[137]:


# Calculate average AHT for most and least frequent call reasons
most_frequent_aht = merged_df[merged_df['primary_call_reason'] == most_frequent_reason]['AHT'].mean()
least_frequent_aht = merged_df[merged_df['primary_call_reason'] == least_frequent_reason]['AHT'].mean()


# In[145]:


# Calculate the percentage difference
percentage_difference = ((most_frequent_aht - least_frequent_aht) / least_frequent_aht) * 100
print(f"Percentage difference in AHT between the most and least frequent call reasons: {percentage_difference:.2f}%")


# In[148]:


# Select numerical columns for correlation (AHT, AST, sentiment, silence percentage)
corr_matrix = merged_df[['AHT', 'AST', 'average_sentiment', 'silence_percent_average']].corr()

# Plot heatmap
plt.figure(figsize=(8,6))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', linewidths=0.5)
plt.title('Correlation Heatmap of AHT, AST, Sentiment and Silence Percentage')
plt.show()


# In[153]:


# Create a column for day of week and hour of the day
merged_df['call_day'] = merged_df['call_start_datetime'].dt.day_name()
merged_df['call_hour'] = merged_df['call_start_datetime'].dt.hour

# Aggregate AHT by day of the week
aht_by_day = merged_df.groupby('call_day')['AHT'].mean().reset_index()

day_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
# Convert 'call_day' to a categorical type with the specified order
merged_df['call_day'] = pd.Categorical(merged_df['call_day'], categories=day_order, ordered=True)

# Aggregate AHT by day of the week
aht_by_day = merged_df.groupby('call_day')['AHT'].mean().reset_index()

# Time series plot for AHT by day
plt.figure(figsize=(12,6))
sns.lineplot(x='call_day', y='AHT', data=aht_by_day, marker='o')
plt.title('AHT Across Days of the Week')
plt.xlabel('Day of the Week')
plt.ylabel('Average AHT (minutes)')
plt.show()

